﻿using System;
using System.IO;

namespace Document
{
    class Program
    {
        static void Main(string[] args)
        {
            //Set Up
            Console.WriteLine("Text file creator");
            Console.WriteLine(" ");
            //Get Name
            Console.WriteLine("What is the name of the document?");
            string docTitle = Console.ReadLine();
            //Get Contents
            Console.WriteLine("What are the contents of the document?");
            string docCont = Console.ReadLine();
            //Append .txt
            string docName = docTitle + ".txt";
            //Write File
            try
            {
                System.IO.File.WriteAllText(docName, docCont);
            }
            //Exception Handling
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            //Goodbye Message
            Console.WriteLine("File was successfully saved.");
        }     
    }
}